# bot.1.py
# Install: pip install -r requirements.txt
# Run: python bot.1.py

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, ConversationHandler, filters

TOKEN = "BOT_TOKENINGIZNI_SHU_YERGA_QOYING"
ADMIN_ID = 8673091062
ASK_FF_ID = 1

MENU = ReplyKeyboardMarkup(
    [[KeyboardButton("🎯 Nastroyka olish")],
     [KeyboardButton("💎 Olmos uchun ariza")],
     [KeyboardButton("👨‍💻 Admin bilan bog‘lanish")]],
    resize_keyboard=True
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Assalomu alaykum! Free Fire botiga xush kelibsiz. Kerakli bo‘limni tanlang:",
        reply_markup=MENU
    )

async def ask_ff_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Free Fire Player ID raqamingizni yuboring. Ariza adminga ko‘rib chiqish uchun yuboriladi."
    )
    return ASK_FF_ID

async def receive_ff_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    player_id = update.message.text.strip()
    if not 4 <= len(player_id) <= 30:
        await update.message.reply_text("ID noto‘g‘ri ko‘rinadi. Qayta yuboring yoki /cancel bosing.")
        return ASK_FF_ID

    user = update.effective_user
    username = f"@{user.username}" if user.username else "username yo‘q"
    msg = (
        "💎 Yangi olmos arizasi!\n"
        f"Ism: {user.full_name}\nTelegram: {username}\n"
        f"Telegram ID: {user.id}\nFree Fire Player ID: {player_id}"
    )
    try:
        await context.bot.send_message(chat_id=ADMIN_ID, text=msg)
        await update.message.reply_text("✅ Arizangiz adminga yuborildi. Natijani admin bildiradi.", reply_markup=MENU)
    except Exception:
        await update.message.reply_text(
            "Ariza yuborilmadi. Admin botni Telegramda /start bilan ochganini tekshiring.",
            reply_markup=MENU
        )
    return ConversationHandler.END

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if text == "🎯 Nastroyka olish":
        await update.message.reply_text(
            "🎯 Nastroyka bo‘limi. Hozircha aniq qiymatlar qo‘shilmagan; "
            "nastroyka raqamlarini bersangiz, shu yerga joylayman.",
            reply_markup=MENU
        )
    elif text == "👨‍💻 Admin bilan bog‘lanish":
        await update.message.reply_text("Admin sizga ariza yuborilganda xabar oladi.", reply_markup=MENU)
    else:
        await update.message.reply_text("Menyudan tanlang.", reply_markup=MENU)

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("Bu bo‘lim faqat admin uchun.")
        return
    await update.message.reply_text("👑 Admin panel: olmos arizalari sizga shaxsiy xabar bo‘lib keladi.")

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bekor qilindi.", reply_markup=MENU)
    return ConversationHandler.END

def main():
    if TOKEN == "BOT_TOKENINGIZNI_SHU_YERGA_QOYING":
        raise SystemExit("Avval TOKEN qatoriga BotFather tokenini kiriting.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^💎 Olmos uchun ariza$"), ask_ff_id)],
        states={ASK_FF_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_ff_id)]},
        fallbacks=[CommandHandler("cancel", cancel)]
    ))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, menu))
    print("Bot ishga tushdi.")
    app.run_polling()

if __name__ == "__main__":
    main()
